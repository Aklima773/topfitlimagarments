1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/6cc61b0645505732.js","/_next/static/chunks/ac598cc4369e10cc.js"],"default"]
3:I[37457,["/_next/static/chunks/6cc61b0645505732.js","/_next/static/chunks/ac598cc4369e10cc.js"],"default"]
0:{"buildId":"bfXpJ00-BZ8ak8Ngm4prH","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":[["$","div","l",{"children":["$undefined","$undefined","$undefined","$undefined","$undefined","$undefined","$undefined","$undefined"]}],[],[]],"isPartial":false}
