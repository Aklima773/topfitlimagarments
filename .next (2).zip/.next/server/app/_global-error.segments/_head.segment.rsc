1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/6cc61b0645505732.js","/_next/static/chunks/ac598cc4369e10cc.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/6cc61b0645505732.js","/_next/static/chunks/ac598cc4369e10cc.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[27201,["/_next/static/chunks/6cc61b0645505732.js","/_next/static/chunks/ac598cc4369e10cc.js"],"IconMark"]
0:{"buildId":"bfXpJ00-BZ8ak8Ngm4prH","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","link","0",{"rel":"icon","href":"/favicon.ico?favicon.f846f27f.ico","sizes":"136x68","type":"image/x-icon"}],["$","$L5","1",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"loading":null,"isPartial":false}
