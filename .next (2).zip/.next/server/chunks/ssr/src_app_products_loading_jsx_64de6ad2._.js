module.exports=[84334,a=>{"use strict";var b=a.i(7997);a.i(717),a.s(["default",0,()=>(0,b.jsx)("div",{children:[...Array(8)].map((a,b)=>{})})],84334)}];

//# sourceMappingURL=src_app_products_loading_jsx_64de6ad2._.js.map