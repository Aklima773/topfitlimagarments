globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/f1b4d49aa9e249c5.js",
    "static/chunks/e7e1ee1f61eff323.js",
    "static/chunks/a545abd9ddc1609d.js",
    "static/chunks/38c470a326e2d234.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/turbopack-3cd1dcec92bc87d4.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];