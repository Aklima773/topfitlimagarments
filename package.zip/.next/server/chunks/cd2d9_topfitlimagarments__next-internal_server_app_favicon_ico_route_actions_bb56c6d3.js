module.exports=[84351,(e,o,d)=>{}];

//# sourceMappingURL=cd2d9_topfitlimagarments__next-internal_server_app_favicon_ico_route_actions_bb56c6d3.js.map