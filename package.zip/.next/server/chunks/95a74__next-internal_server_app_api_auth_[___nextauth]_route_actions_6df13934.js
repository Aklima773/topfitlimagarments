module.exports=[17070,(e,o,d)=>{}];

//# sourceMappingURL=95a74__next-internal_server_app_api_auth_%5B___nextauth%5D_route_actions_6df13934.js.map