module.exports=[71641,a=>{a.v("/_next/static/media/favicon.f846f27f.ico")},37251,a=>{"use strict";let b={src:a.i(71641).default,width:136,height:68};a.s(["default",0,b])}];

//# sourceMappingURL=Desktop_reactproject_top_topfitlimagarments_src_app_afe51466._.js.map