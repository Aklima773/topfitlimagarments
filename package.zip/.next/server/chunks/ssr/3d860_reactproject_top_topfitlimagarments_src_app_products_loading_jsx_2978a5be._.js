module.exports=[45438,a=>{"use strict";var b=a.i(30713);a.i(98030),a.s(["default",0,()=>(0,b.jsx)("div",{children:[...Array(8)].map((a,b)=>{})})],45438)}];

//# sourceMappingURL=3d860_reactproject_top_topfitlimagarments_src_app_products_loading_jsx_2978a5be._.js.map