module.exports=[65818,(a,b,c)=>{}];

//# sourceMappingURL=95a74__next-internal_server_app__global-error_page_actions_cfc0c6af.js.map