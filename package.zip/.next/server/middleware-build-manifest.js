globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/5cdf0bff6285df16.js",
    "static/chunks/5ff23e9c512834d1.js",
    "static/chunks/5d0bb4114a121b3b.js",
    "static/chunks/ce7b365e2f94d602.js",
    "static/chunks/3a10a6cafd3beff4.js",
    "static/chunks/turbopack-ad89019c218f15cb.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];