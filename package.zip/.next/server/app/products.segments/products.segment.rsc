1:"$Sreact.fragment"
2:I[70249,["/_next/static/chunks/8e61958cb81e752d.js","/_next/static/chunks/dfb6ddb533b730a1.js"],"default"]
3:I[64877,["/_next/static/chunks/8e61958cb81e752d.js","/_next/static/chunks/dfb6ddb533b730a1.js"],"default"]
0:{"buildId":"YFjT7pKSgYj4LMhuo7bqQ","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":[["$","div","l",{"children":["$undefined","$undefined","$undefined","$undefined","$undefined","$undefined","$undefined","$undefined"]}],[],[]],"isPartial":false}
