var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_84494e95._.js")
R.c("server/chunks/[root-of-the-server]__fc8117c7._.js")
R.c("server/chunks/4382a_next_55f3e7fb._.js")
R.c("server/chunks/cd2d9_topfitlimagarments__next-internal_server_app_favicon_ico_route_actions_bb56c6d3.js")
R.m(43971)
module.exports=R.m(43971).exports
