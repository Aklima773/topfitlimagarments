1:"$Sreact.fragment"
2:I[73687,["/_next/static/chunks/8e61958cb81e752d.js","/_next/static/chunks/dfb6ddb533b730a1.js"],"ViewportBoundary"]
3:I[73687,["/_next/static/chunks/8e61958cb81e752d.js","/_next/static/chunks/dfb6ddb533b730a1.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[61453,["/_next/static/chunks/8e61958cb81e752d.js","/_next/static/chunks/dfb6ddb533b730a1.js"],"IconMark"]
0:{"buildId":"YFjT7pKSgYj4LMhuo7bqQ","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","link","0",{"rel":"icon","href":"/favicon.ico?favicon.f846f27f.ico","sizes":"136x68","type":"image/x-icon"}],["$","$L5","1",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"loading":null,"isPartial":false}
