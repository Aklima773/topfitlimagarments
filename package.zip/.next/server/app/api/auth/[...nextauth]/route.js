var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[root-of-the-server]__d743064e._.js")
R.c("server/chunks/Desktop_reactproject_top_topfitlimagarments_40ba0ae2._.js")
R.c("server/chunks/[root-of-the-server]__fc8117c7._.js")
R.c("server/chunks/95a74__next-internal_server_app_api_auth_[___nextauth]_route_actions_6df13934.js")
R.m(72733)
module.exports=R.m(72733).exports
